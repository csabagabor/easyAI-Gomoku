from .TicTacToe import TicTacToe
from .ConnectFour import ConnectFour
from .Gomoku import Gomoku
from .Gomoku_Strategic import  Gomoku_Strategic
from .Negamax_Iterative_Deepening import Negamax_Iterative_Deepening
from .AI_Player_Iterative_Deepening import AI_Player_Iterative_Deepening